#ifndef SORT_H
#define SORT_H

void sort(char** toSort, int size);

#endif
