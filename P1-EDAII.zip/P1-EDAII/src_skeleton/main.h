/* 
 * File:   main.h
 * Author: francesco
 *
 * Created on May 4, 2018, 7:37 PM
 */

#ifndef MAIN_H
#define MAIN_H

#define INFO_FILE_PATH "data_dict.tsv"
#define QUERY_FILE_PATH "data_list.tsv"


#endif /* MAIN_H */

